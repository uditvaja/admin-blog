# ADMIN_PANNEL
ADMIN_PANNEL using HTML_CSS_JQUERY
<br>
<br>

<img width="960" alt="Screenshot 2023-12-01 114030" src="https://github.com/kuuunnjj/ADMIN_PANNEL/assets/127201867/ce9615d8-44c4-4c48-be7d-3027d9f09d30">


<img width="960" alt="Screenshot 2023-12-01 114116" src="https://github.com/kuuunnjj/ADMIN_PANNEL/assets/127201867/c476b0d1-4364-4e77-874a-5d0e8693e5f9">

<img width="960" alt="Screenshot 2023-12-01 114054" src="https://github.com/kuuunnjj/ADMIN_PANNEL/assets/127201867/fc347947-a19f-4806-a266-f75b4f380f3c">


